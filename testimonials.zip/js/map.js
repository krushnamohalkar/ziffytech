$(function ()  {
	
    var pos = new google.maps.LatLng(18.5653255,73.7741786);
		var pos1 = new google.maps.LatLng(19.1912017,72.9739594);
    var map = new google.maps.Map($('#map')[0], {
        center: pos,
        center: pos1,
        zoom: 7,
        mapTypeId: google.maps.MapTypeId.ROAD,
		styles: [{
    stylers: [{
      saturation: -100
    }]
  }]
    });

    var marker = new google.maps.Marker({
        position: pos,
        map: map
    });
    var marker1 = new google.maps.Marker({
        position: pos1,
        map: map
    });
    marker.tooltipContent = 'At Pune';
    marker1.tooltipContent = 'At Thane, Mumbai';
    var infoWindow = new google.maps.InfoWindow({
        content: 'At Pune'
    });
	var infoWindow1 = new google.maps.InfoWindow({
        content: 'At Thane, Mumbai'
    });

    google.maps.event.addListener(marker, 'click', function () {
        infoWindow.open(map, marker);
    });
    google.maps.event.addListener(marker1, 'click', function () {
        infoWindow1.open(map, marker1);
    });

    google.maps.event.addListener(marker, 'mouseover', function () {
        var point = fromLatLngToPoint(marker.getPosition(), map);
        $('#marker-tooltip').html(marker.tooltipContent).css({
            'left': point.x,
                'top': point.y
        }).show();
    });
    
    google.maps.event.addListener(marker1, 'mouseover', function () {
        var point = fromLatLngToPoint(marker1.getPosition(), map);
        /*$('#marker1-tooltip').html(marker1.tooltipContent + '<br>Pixel coordinates: ' + point.x + ', ' + point.y).css({
            'left': point.x,
                'top': point.y
        }).show();*/
		$('#marker1-tooltip').html(marker1.tooltipContent).css({
            'left': point.x,
                'top': point.y
        }).show();
    });

    google.maps.event.addListener(marker, 'mouseout', function () {
        $('#marker-tooltip').hide();
    });
    google.maps.event.addListener(marker1, 'mouseout', function () {
        $('#marker1-tooltip').hide();
    });
    
});

function fromLatLngToPoint(latLng, map) {
    var topRight = map.getProjection().fromLatLngToPoint(map.getBounds().getNorthEast());
    var bottomLeft = map.getProjection().fromLatLngToPoint(map.getBounds().getSouthWest());
    var scale = Math.pow(2, map.getZoom());
    var worldPoint = map.getProjection().fromLatLngToPoint(latLng);
    return new google.maps.Point((worldPoint.x - bottomLeft.x) * scale, (worldPoint.y - topRight.y) * scale);
}